# OnlineGroeryStore
In this project, we implement an online grocery store, in which people can purchase grocies using this website at the convenience of their home

Lets get stared
1. Registration Page
To get started with using the GroceryMart website, first you will need to create your credentials via Registration page
Explaination: This is Registration form which consist of Name,Email,Password,Confirm Password, Profile pic where we upload user’s pic .The users entered details are stored.Register button submits users information within one click.

2. Login Page
Once you have your login credentials ready you need to login to the website via the login page.
This can be done in the following way

Explaination:
This is the login page where email and password is stored to maintain contact with the user or can be used for advertisement.
3. Home
Once you login into page, you will enter the main page of website. This page introduces you to grocery shopping.

Explaination: This is the page after the login credentials.This is the front page of the Online grocery store to interact with the user.
4. Shop
After clicking vegetables category

Explaination: This is the page where we can see groceries along with their price
,add to wishlist and add to cart buttons where we can order vegetables,etc.
5. Cart

Explaination: This is where the user chosen groceries are loaded in the cart
.Their total price is calculated and displayed.We can even continue shopping,delete the items selected and proceed to checkout.
6. Checkout
Explaination:
The user fills his/her details and address to the items loaded to its destination.
Orders

Explaination: The customer’s identity , address, payment method, items/orders placed, total price of the orders and delivery status is shown over here.
7. Messages
Explaination: The customers feedback along with his/her information can be noted and stored after one click of Send Message. This can be used to improve customer service.
 
Website link: https://grocerymart1234.000webhostapp.com/home.php
