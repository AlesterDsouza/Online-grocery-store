<?php

$db_name = "mysql:host=localhost;dbname=id20021769_grocerymartdatabase";
$username = "id20021769_shop_db";
$password = "e|PH*CSCa2hwiE{l";

$conn = new PDO($db_name, $username, $password);

?>